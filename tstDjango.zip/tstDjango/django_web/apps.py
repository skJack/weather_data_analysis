from django.apps import AppConfig


class DjangoWebConfig(AppConfig):
    name = 'django_web'
